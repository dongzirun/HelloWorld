// Type definitions for iview 2.5.1
// Project: https://github.com/iview/iview
// Definitions by: yangdan
// Definitions: https://github.com/yangdan8/iview.git
import Vue from "vue";

export default Page;

export interface Page extends Vue {
  /**
   * 当前页码，支持 .sync 修饰符
   * @default 1
   */
  current: number;
  /**
   * 数据总数
   * @default 0
   */
  total: number;
  /**
   * 每页条数
   * @default 10
   */
  'page-size': number;
  /**
   * 每页条数切换的配置
   * @default [10, 20, 30, 40]
   */
  'page-size-opts': number[];
  /**
   * 条数切换弹窗的展开方向，可选值为 bottom 和 top
   * @default bottom
   */
  placement: string;
  /**
   * 可选值为small（迷你版）或不填（默认）
   */
  size: string;
  /**
   * 简洁版
   * @default false
   */
  simple: boolean;
  /**
   * 显示总数
   * @default false
   */
  'show-total': boolean;
  /**
   * 显示电梯，可以快速切换到某一页
   * @default false
   */
  'show-elevator': boolean;
  /**
   * 显示分页，用来改变page-size
   * @default false
   */
  'show-sizer': boolean;
  /**
   * 自定义 class 名称
   */
  'class-name': string;
  /**
   * 自定义 style 样式
   */
  styles: object;
  /**
   * 页码改变的回调，返回改变后的页码
   * @param pageNum 页码
   */
  $emit(eventName: 'on-change', pageNum: number): this;
  /**
   * 切换每页条数时的回调，返回切换后的每页条数
   * @param pageSize 每页条数
   */
  $emit(eventName: 'on-page-size-change', pageSize: number): this;
  /**
   * slot插槽对象
   */
  $slot: {
    /**
     * 自定义显示总数的内容
     */
    '': Vue
  };
}