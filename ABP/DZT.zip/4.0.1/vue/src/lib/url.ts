const URL = process.env.NODE_ENV === 'production' ? 'http://app.abzschina.com/AnBang/' : 'http://localhost:21021/';
export default URL;